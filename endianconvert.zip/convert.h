unsigned int convert16(unsigned int);
unsigned int convert32(unsigned int);
unsigned int convert64(unsigned int);