unsigned int convert16(unsigned int a)
{
  return (a>>8) | (a<<8)

}