
#include<stdio.h>
#include "convert.h"

char *check_endian_type(void);
union data{
  unsigned int val;
  char *type;
  int size;
};
unsigned int convert(union data);
int main(void)
{
unsigned int x=12;
union data d;
d.type=check_endian_type();
if(d.type=="LSB")
printf("\n Conversion from LSB to MSB: ");
else if(d.type=="MSB")
printf("\n Conversion from MSB to LSB: ");
d.val=x;
unsigned int y=convert(d);
printf("\nBefore conversion %X",x);
printf("\n After conversion %X,y);
return 0;
}

char *check_endian_type(void)
{

unsigned int a=1;
char *c=(char*) &a;
if ( (int)*c==1)
return "LSB";
else if((int)*c==0)
return "MSB";
}
unsigned int convert(union data d)
{
unsigned int a=d.val;
d.size=sizeof(unsigned int)*8;//bits

if(d.size==16)
return convert16(a);
else if(d.size==32)
return convert32(a);
else if(d.size==64)
return convert64(a);
}